import zipfile
import os
import shutil

myPath = "Input/"
if os.listdir(myPath):
    print("Error, input file already contains files. Please clear out these files before proceeding")
    quit()

fileArray = os.listdir()
zipFileArray = []
for item in fileArray:
    if len(item) > 4:
        if item[-4:] == ".zip":
            zipFileArray.append(item)

for item in zipFileArray:
    print(item)
    with zipfile.ZipFile(item, 'r') as zip_ref:
        zip_ref.extractall("Input")
    zip_ref.close()

fileArray = os.listdir(myPath)
for item in fileArray:
    if os.path.isdir(myPath + item + "/"):
        myPath += (item + "/")

fileArray = os.listdir(myPath)
zipFileArray = []
for item in fileArray:
    if len(item) > 4:
        if item[-4:] == ".zip":
            zipFileArray.append(item)

for item in zipFileArray:
    print(item)
    with zipfile.ZipFile(myPath + item, 'r') as zip_ref:
        zip_ref.extractall("Input")
    zip_ref.close()

shutil.rmtree(myPath[0:-1])
myPath = "Input/"
fileArray = os.listdir(myPath)
for item in fileArray:
    myPath = "Input/"
    if os.path.isdir(myPath + item + "/"):
        myPath += (item + "/")
        zipFileArray = []
        newFileArray = os.listdir(myPath)
        for sub_item in newFileArray:
            print(sub_item)
            if len(sub_item) > 4:
                if sub_item[-4:] == ".zip":
                    with zipfile.ZipFile(myPath + sub_item, 'r') as zip_ref:
                        zip_ref.extractall("Input")
                    zip_ref.close()
                    os.rename("Input/" + sub_item[0:-4], "Input/" + item + " - " + sub_item)
                    shutil.rmtree(myPath[0:-1])
                elif sub_item[-4:] == ".rar":
                    print("Warning: RAR file detected. Item being skipped..")

myPath = "Input/"
fileArray = os.listdir(myPath)
for item in fileArray:
    file_names = os.listdir(myPath + item + "/")
    for file_name in file_names:
        if file_name[-4:] != ".rar" and (file_name[-4:] == ".cpp" or file_name[-2:] == ".h" or file_name[-4:] == ".txt" or os.path.isdir(myPath + item + "/" + file_name + "/")):
            shutil.move(myPath + item + "/" + file_name, myPath)
            os.rename(myPath + file_name, myPath + item + " - " + file_name)
    shutil.rmtree(myPath + item)

fileArray = os.listdir(myPath)
for item in fileArray:
    if os.path.isdir(myPath + item + "/"):
        file_names = os.listdir(myPath + item + "/")
        for file_name in file_names:
            if file_name[-4:] == ".cpp" or file_name[-2:] == ".h" or file_name[-4:] == ".txt":
                shutil.move(myPath + item + "/" + file_name, myPath)
                os.rename(myPath + file_name, myPath + item + " - " + file_name)
            shutil.rmtree(myPath + item)

